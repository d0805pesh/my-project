export interface Scheme {
  id: string;
  title: string;
  ministry: string;
  sector: string;
  tags: string[];
  description: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
  isThinking?: boolean;
}

export interface StatMetric {
  name: string;
  value: number;
  color: string;
}

export enum ViewState {
  HOME = 'HOME',
  SEARCH = 'SEARCH',
  DASHBOARD = 'DASHBOARD'
}