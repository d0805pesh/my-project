import React from 'react';
import { ShieldCheck, BarChart3, Search, Home } from 'lucide-react';
import { ViewState } from '../types';

interface NavbarProps {
  currentView: ViewState;
  setView: (view: ViewState) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentView, setView }) => {
  return (
    <nav className="sticky top-0 z-50 w-full bg-white border-b border-slate-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          {/* Logo */}
          <div 
            className="flex-shrink-0 flex items-center cursor-pointer gap-2"
            onClick={() => setView(ViewState.HOME)}
          >
            <div className="w-8 h-8 bg-gov-blue rounded-lg flex items-center justify-center text-white">
              <ShieldCheck size={20} />
            </div>
            <span className="font-bold text-xl tracking-tight text-slate-800">
              Policy<span className="text-gov-blue">Copilot</span>
            </span>
          </div>

          {/* Nav Links */}
          <div className="hidden sm:flex sm:space-x-8">
            <button
              onClick={() => setView(ViewState.HOME)}
              className={`${
                currentView === ViewState.HOME
                  ? 'border-gov-blue text-slate-900'
                  : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
              } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium transition-colors`}
            >
              <Home className="mr-2 h-4 w-4" />
              Home
            </button>
            <button
              onClick={() => setView(ViewState.SEARCH)}
              className={`${
                currentView === ViewState.SEARCH
                  ? 'border-gov-blue text-slate-900'
                  : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
              } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium transition-colors`}
            >
              <Search className="mr-2 h-4 w-4" />
              Find Schemes
            </button>
            <button
              onClick={() => setView(ViewState.DASHBOARD)}
              className={`${
                currentView === ViewState.DASHBOARD
                  ? 'border-gov-blue text-slate-900'
                  : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
              } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium transition-colors`}
            >
              <BarChart3 className="mr-2 h-4 w-4" />
              Stats Dashboard
            </button>
          </div>

          {/* Mobile Menu Button (Simplified) */}
          <div className="sm:hidden flex items-center">
             <button onClick={() => setView(ViewState.SEARCH)} className="text-gov-blue font-medium">
                Launch App
             </button>
          </div>
        </div>
      </div>
    </nav>
  );
};