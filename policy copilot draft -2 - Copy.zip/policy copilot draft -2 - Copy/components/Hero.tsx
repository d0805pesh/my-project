import React from 'react';
import { ArrowRight, Search, Shield, Users, BookOpen } from 'lucide-react';
import { ViewState } from '../types';

interface HeroProps {
  onGetStarted: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onGetStarted }) => {
  return (
    <div className="relative overflow-hidden bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="relative z-10 pb-8 bg-white sm:pb-16 md:pb-20 lg:max-w-2xl lg:w-full lg:pb-28 xl:pb-32">
          <svg
            className="hidden lg:block absolute right-0 inset-y-0 h-full w-48 text-white transform translate-x-1/2"
            fill="currentColor"
            viewBox="0 0 100 100"
            preserveAspectRatio="none"
            aria-hidden="true"
          >
            <polygon points="50,0 100,0 50,100 0,100" />
          </svg>

          <main className="mt-10 mx-auto max-w-7xl px-4 sm:mt-12 sm:px-6 md:mt-16 lg:mt-20 lg:px-8 xl:mt-28">
            <div className="sm:text-center lg:text-left">
              <h1 className="text-4xl tracking-tight font-extrabold text-slate-900 sm:text-5xl md:text-6xl">
                <span className="block xl:inline">Democratizing access to</span>{' '}
                <span className="block text-gov-blue xl:inline">Government Schemes</span>
              </h1>
              <p className="mt-3 text-base text-slate-500 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl lg:mx-auto">
                PolicyCopilot uses advanced AI to help citizens, startups, and NGOs discover, understand, and apply for eligible Indian government schemes instantly.
              </p>
              <div className="mt-5 sm:mt-8 sm:flex sm:justify-center lg:justify-start">
                <div className="rounded-md shadow">
                  <button
                    onClick={onGetStarted}
                    className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-gov-blue hover:bg-primary-700 md:py-4 md:text-lg transition-all"
                  >
                    Find Schemes Now
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </button>
                </div>
                <div className="mt-3 sm:mt-0 sm:ml-3">
                  <button
                    onClick={() => {}} 
                    className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-gov-blue bg-primary-100 hover:bg-primary-200 md:py-4 md:text-lg transition-all"
                  >
                    Live Dashboard
                  </button>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
      <div className="lg:absolute lg:inset-y-0 lg:right-0 lg:w-1/2 bg-slate-50 flex items-center justify-center">
         <div className="grid grid-cols-2 gap-4 p-8 opacity-80">
            <div className="bg-white p-6 rounded-xl shadow-lg flex flex-col items-center text-center">
                <Search className="h-10 w-10 text-gov-orange mb-3" />
                <h3 className="font-bold text-slate-800">Smart Search</h3>
                <p className="text-sm text-slate-500">Find schemes by simply describing your profile.</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-lg flex flex-col items-center text-center mt-8">
                <Shield className="h-10 w-10 text-gov-blue mb-3" />
                <h3 className="font-bold text-slate-800">Verified Data</h3>
                <p className="text-sm text-slate-500">Sourced directly from official government portals.</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-lg flex flex-col items-center text-center">
                <Users className="h-10 w-10 text-gov-green mb-3" />
                <h3 className="font-bold text-slate-800">For Everyone</h3>
                <p className="text-sm text-slate-500">Farmers, Students, Entrepreneurs, and more.</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-lg flex flex-col items-center text-center mt-8">
                <BookOpen className="h-10 w-10 text-primary-500 mb-3" />
                <h3 className="font-bold text-slate-800">Easy Apply</h3>
                <p className="text-sm text-slate-500">Get direct links and document checklists.</p>
            </div>
         </div>
      </div>
    </div>
  );
};