import React from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, Legend
} from 'recharts';
import { TrendingUp, Users, FileCheck, IndianRupee } from 'lucide-react';

const SECTOR_DATA = [
  { name: 'Agriculture', value: 450 },
  { name: 'Education', value: 320 },
  { name: 'Health', value: 280 },
  { name: 'MSME', value: 210 },
  { name: 'Women', value: 190 },
];

const STATE_DATA = [
  { name: 'Central', value: 120, schemes: 45 },
  { name: 'Karnataka', value: 98, schemes: 32 },
  { name: 'Maharashtra', value: 86, schemes: 28 },
  { name: 'UP', value: 90, schemes: 40 },
  { name: 'Tamil Nadu', value: 85, schemes: 25 },
];

const COLORS = ['#FF9933', '#138808', '#000080', '#0ea5e9', '#8b5cf6'];

export const Dashboard: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8 space-y-8">
      
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
         <div>
            <h2 className="text-2xl font-bold text-slate-800">Live Policy Dashboard</h2>
            <p className="text-slate-500">Real-time insights from scraped government portals</p>
         </div>
         <div className="flex gap-2">
             <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium flex items-center">
                 <span className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></span>
                 System Operational
             </span>
             <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-medium">
                 Last Updated: 10m ago
             </span>
         </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex items-center">
            <div className="p-3 rounded-lg bg-orange-100 text-orange-600 mr-4">
                <FileCheck size={24} />
            </div>
            <div>
                <p className="text-sm text-slate-500 font-medium">Total Schemes</p>
                <h3 className="text-2xl font-bold text-slate-800">2,450+</h3>
            </div>
        </div>
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex items-center">
            <div className="p-3 rounded-lg bg-blue-100 text-blue-600 mr-4">
                <Users size={24} />
            </div>
            <div>
                <p className="text-sm text-slate-500 font-medium">Beneficiaries</p>
                <h3 className="text-2xl font-bold text-slate-800">12.5M</h3>
            </div>
        </div>
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex items-center">
            <div className="p-3 rounded-lg bg-green-100 text-green-600 mr-4">
                <IndianRupee size={24} />
            </div>
            <div>
                <p className="text-sm text-slate-500 font-medium">Funds Disbursed</p>
                <h3 className="text-2xl font-bold text-slate-800">₹450 Cr</h3>
            </div>
        </div>
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex items-center">
            <div className="p-3 rounded-lg bg-purple-100 text-purple-600 mr-4">
                <TrendingUp size={24} />
            </div>
            <div>
                <p className="text-sm text-slate-500 font-medium">Daily Queries</p>
                <h3 className="text-2xl font-bold text-slate-800">8,900</h3>
            </div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Sector Distribution */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
            <h3 className="text-lg font-semibold text-slate-800 mb-6">Schemes by Sector</h3>
            <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                        <Pie
                            data={SECTOR_DATA}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={80}
                            paddingAngle={5}
                            dataKey="value"
                        >
                            {SECTOR_DATA.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                        </Pie>
                        <Tooltip />
                        <Legend />
                    </PieChart>
                </ResponsiveContainer>
            </div>
        </div>

        {/* State Wise Distribution */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
            <h3 className="text-lg font-semibold text-slate-800 mb-6">Top States by Active Schemes</h3>
            <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={STATE_DATA} layout="vertical" margin={{ left: 20 }}>
                        <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                        <XAxis type="number" hide />
                        <YAxis dataKey="name" type="category" width={100} tick={{fontSize: 12}} />
                        <Tooltip cursor={{fill: 'transparent'}} />
                        <Bar dataKey="value" fill="#0ea5e9" radius={[0, 4, 4, 0]} barSize={20} />
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </div>
      </div>

      {/* Recent Updates Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50">
            <h3 className="font-semibold text-slate-800">Recently Added Schemes</h3>
        </div>
        <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200">
                <thead className="bg-slate-50">
                    <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Scheme Name</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Ministry</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Date Added</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                    </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-200">
                    {[
                        { name: 'PM Vishwakarma Yojana', ministry: 'MSME', date: '2023-10-15', status: 'Active' },
                        { name: 'Lakhpati Didi', ministry: 'Rural Dev', date: '2023-11-01', status: 'Active' },
                        { name: 'Green Hydrogen Mission', ministry: 'Power', date: '2023-09-20', status: 'Active' },
                    ].map((row, idx) => (
                        <tr key={idx}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">{row.name}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">{row.ministry}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">{row.date}</td>
                            <td className="px-6 py-4 whitespace-nowrap">
                                <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                    {row.status}
                                </span>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
      </div>
    </div>
  );
};