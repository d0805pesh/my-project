import React, { useState, useRef, useEffect } from 'react';
import { Send, User, Bot, Loader2, Sparkles } from 'lucide-react';
import { ChatMessage } from '../types';
import { getPolicyAdvice } from '../services/geminiService';
import ReactMarkdown from 'react-markdown';

export const ChatInterface: React.FC = () => {
  const [query, setQuery] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'model',
      text: "Namaste! I am PolicyCopilot. Tell me about yourself (e.g., 'I am a female entrepreneur in Karnataka' or 'I am a farmer looking for subsidies'), and I will find the best government schemes for you.",
      timestamp: new Date(),
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!query.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: query,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setQuery('');
    setIsLoading(true);

    const aiResponseText = await getPolicyAdvice(query);

    const botMsg: ChatMessage = {
      id: (Date.now() + 1).toString(),
      role: 'model',
      text: aiResponseText,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, botMsg]);
    setIsLoading(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)] max-w-5xl mx-auto p-4 md:p-6 bg-slate-50">
      
      {/* Header Area */}
      <div className="mb-6 text-center">
        <h2 className="text-2xl font-bold text-slate-800 flex items-center justify-center gap-2">
          <Sparkles className="text-gov-orange" />
          AI Scheme Finder
        </h2>
        <p className="text-slate-500 text-sm">Powered by Gemini 2.5 Flash & Real-time RAG Pipeline</p>
      </div>

      {/* Chat Area */}
      <div className="flex-1 overflow-y-auto mb-4 space-y-4 pr-2 scrollbar-hide">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex w-full ${
              msg.role === 'user' ? 'justify-end' : 'justify-start'
            }`}
          >
            <div
              className={`flex max-w-[90%] md:max-w-[80%] ${
                msg.role === 'user'
                  ? 'flex-row-reverse'
                  : 'flex-row'
              } gap-3`}
            >
              <div
                className={`flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center ${
                  msg.role === 'user' ? 'bg-gov-blue text-white' : 'bg-white border border-slate-200 text-gov-green'
                }`}
              >
                {msg.role === 'user' ? <User size={20} /> : <Bot size={20} />}
              </div>
              
              <div
                className={`p-4 rounded-2xl shadow-sm text-sm md:text-base ${
                  msg.role === 'user'
                    ? 'bg-gov-blue text-white rounded-tr-none'
                    : 'bg-white border border-slate-200 text-slate-800 rounded-tl-none'
                }`}
              >
                 <ReactMarkdown 
                    className="prose prose-sm max-w-none prose-p:leading-normal prose-li:my-0"
                    components={{
                        strong: ({node, ...props}) => <span className="font-semibold text-gov-blue" {...props} />,
                        ul: ({node, ...props}) => <ul className="list-disc ml-4 space-y-1" {...props} />
                    }}
                 >
                    {msg.text}
                 </ReactMarkdown>
                <div className={`text-xs mt-2 ${msg.role === 'user' ? 'text-primary-200' : 'text-slate-400'}`}>
                  {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start w-full">
            <div className="flex items-center gap-3">
               <div className="h-10 w-10 rounded-full bg-white border border-slate-200 flex items-center justify-center text-gov-green">
                 <Bot size={20} />
               </div>
               <div className="bg-white border border-slate-200 px-4 py-3 rounded-2xl rounded-tl-none shadow-sm flex items-center gap-2">
                 <Loader2 className="animate-spin text-gov-orange" size={16} />
                 <span className="text-slate-500 text-sm">Analyzing policies...</span>
               </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="bg-white border border-slate-200 rounded-2xl p-2 shadow-sm flex items-end gap-2">
        <textarea
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Describe your profile or ask about a scheme..."
          className="flex-1 max-h-32 min-h-[50px] p-3 bg-transparent border-none focus:ring-0 resize-none text-slate-800 placeholder-slate-400"
          rows={1}
        />
        <button
          onClick={handleSend}
          disabled={isLoading || !query.trim()}
          className="h-12 w-12 flex items-center justify-center rounded-xl bg-gov-blue text-white hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors mb-[1px]"
        >
          <Send size={20} />
        </button>
      </div>
      
      <div className="mt-2 flex justify-center gap-2">
         {['Female Entrepreneur', 'Farmer Loan Waiver', 'Student Scholarship', 'MSME Subsidy'].map(tag => (
             <button 
                key={tag}
                onClick={() => setQuery(tag)}
                className="text-xs px-3 py-1 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors"
             >
                {tag}
             </button>
         ))}
      </div>
    </div>
  );
};