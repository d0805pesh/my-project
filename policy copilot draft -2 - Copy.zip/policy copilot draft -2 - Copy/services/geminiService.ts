import { GoogleGenAI, HarmCategory, HarmBlockThreshold } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

const SYSTEM_INSTRUCTION = `
You are PolicyCopilot, an expert AI assistant for Indian Government Schemes. 
Your goal is to help citizens, entrepreneurs, and NGOs find relevant schemes based on their profile.
- Provide accurate, structured information about eligibility, benefits, and application processes.
- Format your response using Markdown. Use bold for headers and lists for criteria.
- If the user asks about a specific sector (e.g., agriculture, tech startups), suggest top 3 real government schemes.
- Be concise but helpful.
- If you don't know a specific detail, advise checking the official portal.
- Maintain a professional, helpful, and patriotic tone.
`;

export const getPolicyAdvice = async (query: string): Promise<string> => {
  if (!apiKey) {
    return "API Key is missing. Please configure the environment.";
  }

  try {
    const model = 'gemini-2.5-flash';
    const response = await ai.models.generateContent({
      model,
      contents: [
        {
          role: 'user',
          parts: [{ text: query }]
        }
      ],
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      }
    });

    return response.text || "I couldn't generate a response at this time.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Sorry, I encountered an error while fetching policy details. Please try again.";
  }
};