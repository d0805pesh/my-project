import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ChatInterface } from './components/ChatInterface';
import { Dashboard } from './components/Dashboard';
import { ViewState } from './types';

export default function App() {
  const [currentView, setView] = useState<ViewState>(ViewState.HOME);

  const renderContent = () => {
    switch (currentView) {
      case ViewState.HOME:
        return <Hero onGetStarted={() => setView(ViewState.SEARCH)} />;
      case ViewState.SEARCH:
        return <ChatInterface />;
      case ViewState.DASHBOARD:
        return <Dashboard />;
      default:
        return <Hero onGetStarted={() => setView(ViewState.SEARCH)} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      <Navbar currentView={currentView} setView={setView} />
      <main className="flex-grow">
        {renderContent()}
      </main>
      
      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-slate-400">
                © {new Date().getFullYear()} PolicyCopilot. A Citizen Initiative.
            </p>
            <div className="flex gap-6 text-sm text-slate-500">
                <a href="#" className="hover:text-gov-blue">Privacy Policy</a>
                <a href="#" className="hover:text-gov-blue">Terms of Use</a>
                <a href="#" className="hover:text-gov-blue">Contact Support</a>
            </div>
        </div>
      </footer>
    </div>
  );
}